"""Find where translation starts in a plasmid, with the evidence for it.

Best evidence first: an annotated start codon, an annotated CDS running into the cloning region,
then a ribosome-binding-site-like motif before an ATG (see ``vectorio.cassette_starts``).
The cloning sites are not guessed here; an annotated MCS is only a landmark.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from Bio.Seq import Seq

from .vector import STOP_CODONS, Vector
from .vectorio import (
    EXPRESSED_PARTNER,
    LACZ_ALPHA_START,
    RBS_MOTIFS,
    cassette_starts,
    feature_text,
    is_start_codon_feature,
    normalize_orientation,
)

_MCS = re.compile(r"multiple cloning site|\bmcs\b|polylinker|poly-linker", re.I)
_NOT_EXPRESSED = re.compile(
    r"resistance|lactamase|repressor|replication|aminoglycoside|phosphotransferase|"
    r"chloramphenicol|kanamycin|ampicillin|tetracycline|neomycin|hygromycin|streptomycin|"
    r"spectinomycin|gentamicin|\b(kan|amp|cam|tet|bla|cat|lac[iz]|rop|rep[a-z]?|ori)\w*\b",
    re.I,
)

N_TERMINAL_PREVIEW = 30
CONFIDENCE_RANK = {"high": 0, "medium": 1, "low": 2}


@dataclass(frozen=True)
class StartCandidate:
    position: int  # 0-based index of the A of ATG on the plus strand
    confidence: str  # "high" | "medium" | "low"
    evidence: tuple[str, ...]
    orf_end: int  # end of the ORF (stop codon included), 0-based exclusive
    n_terminal: str  # residues encoded between the start codon and the cloning region


@dataclass(frozen=True)
class Region:
    start: int
    end: int
    source: str  # always "annotation: MCS"; the region is never guessed


@dataclass
class VectorAnalysis:
    vector: Vector  # in the standard orientation
    flipped: bool
    orientation_notes: list[str]
    starts: list[StartCandidate]
    region: Region | None  # the annotated MCS, a landmark only
    warnings: list[str] = field(default_factory=list)

    @property
    def best_start(self) -> StartCandidate | None:
        return self.starts[0] if self.starts else None

    @property
    def ready(self) -> bool:
        """True when the start codon needs no confirmation."""
        start = self.best_start
        return bool(start and start.confidence == "high")


def find_region(vector: Vector) -> Region | None:
    """The annotated MCS, if the file has one.  Never guessed."""
    for f in vector.record.features:
        if f.type != "source" and _MCS.search(feature_text(f)):
            return Region(int(f.location.start), int(f.location.end), "annotation: MCS")
    return None


def _orf_end(seq: str, start: int) -> int | None:
    for i in range(start, len(seq) - 2, 3):
        if seq[i : i + 3] in STOP_CODONS:
            return i + 3
    return None


def _sd_score(seq: str, atg: int) -> int:
    window = seq[max(0, atg - 16) : max(0, atg - 3)]
    return max((len(m) for m in RBS_MOTIFS if m in window), default=0)


KOZAK = re.compile(r"(?=(GCC[AG]CCATGG))")


def find_starts(vector: Vector, region: Region | None) -> list[StartCandidate]:
    seq = vector.seq
    found: dict[int, dict] = {}

    def add(pos, why, strength):
        entry = found.setdefault(pos, {"why": [], "strength": 0})
        entry["why"].append(why)
        entry["strength"] += strength

    for f in vector.record.features:
        if f.location.strand == -1:
            continue
        s, e = int(f.location.start), int(f.location.end)
        if is_start_codon_feature(f, seq):
            add(s, f"annotated as the start codon ({feature_label(f)})", 3)
        elif f.type == "CDS" and e - s >= 90 and seq[s : s + 3] == "ATG":
            text = feature_text(f)
            partner = bool(EXPRESSED_PARTNER.search(text))
            if _NOT_EXPRESSED.search(text) and not partner:
                continue  # resistance, repressor, replication; a lacZ-alpha or MalE fusion is kept
            stop = _orf_end(seq, s)
            if region and s <= region.start and stop and stop > region.start:
                add(
                    s,
                    f"annotated CDS '{feature_label(f)}' reads in frame into the cloning region",
                    2,
                )
            elif not region and partner:
                add(
                    s,
                    f"annotated fusion-partner CDS '{feature_label(f)}' "
                    "(no cloning region is annotated)",
                    2,
                )

    if region:
        for pos in range(len(seq) - 2):
            if seq[pos : pos + 3] != "ATG" or pos >= region.start:
                continue
            sd = _sd_score(seq, pos)
            stop = _orf_end(seq, pos)
            if sd >= 4 and stop and stop > region.start:
                add(
                    pos,
                    f"ribosome-binding-site-like motif ({sd} nt) upstream, ORF reaches the MCS",
                    1 + (sd >= 5),
                )

    # a full Kozak consensus is rare by chance (about 1 in 1000 sites), so a long ORF behind one
    # is worth offering, though only as a medium-confidence start
    for hit in re.finditer(KOZAK, seq):
        pos = hit.start() + 6
        stop = _orf_end(seq, pos)
        if stop and stop - pos >= 90:
            add(pos, "Kozak consensus (GCCRCCATGG) around the ATG", 2)

    for hit in re.finditer(LACZ_ALPHA_START, seq):
        add(hit.start(), "matches the start of lacZ-alpha (MTMITPS...)", 3)

    for c in cassette_starts(seq):
        stop = _orf_end(seq, c.position)
        # an ATG in an NcoI/NdeI site is the vector's own start however short the frame to
        # the next stop; one found only by its promoter has to open a real reading frame
        if not stop or not (c.site or stop - c.position >= 90):
            continue
        if region and c.position >= region.end:
            continue
        where = f"inside the {c.site} site" if c.site else f"behind a {c.promoter}"
        add(
            c.position,
            f"RBS-like motif ({c.rbs} nt) then ATG {where}",
            2 + bool(c.site and c.promoter),
        )

    out = []
    for pos, entry in found.items():
        stop = _orf_end(seq, pos)
        if stop is None:
            continue
        agree = len(entry["why"]) >= 2
        strength = entry["strength"]
        conf = (
            "high"
            if strength >= 3 and (agree or region is None or stop > region.start)
            else ("medium" if strength >= 2 else "low")
        )
        # residues the vector adds in front of the cloning site; if the file does not say
        # where that is, the first stretch is still enough to recognise a tag
        reach = (region.start - pos) // 3 if region and region.start > pos else N_TERMINAL_PREVIEW
        n = min(reach, (stop - pos) // 3 - 1, 60)
        n_term = str(Seq(seq[pos : pos + 3 * n]).translate())
        out.append(StartCandidate(pos, conf, tuple(entry["why"]), stop, n_term))
    out.sort(key=lambda c: (CONFIDENCE_RANK[c.confidence], -len(c.evidence), c.position))
    return out


def feature_label(feature) -> str:
    for key in ("label", "name", "product", "gene"):
        for value in feature.qualifiers.get(key, []):
            text = re.sub(r"<[^>]+>", " ", str(value)).strip()
            if text:
                return text[:40]
    return feature.type


def analyze_vector(vector: Vector) -> VectorAnalysis:
    """Orient the vector, then find its start codon candidates."""
    vector, flipped, notes = normalize_orientation(vector)
    region = find_region(vector)
    starts = find_starts(vector, region)

    warnings: list[str] = []
    if not starts:
        warnings.append("No start codon could be found; point to one to continue.")
    elif starts[0].confidence != "high":
        warnings.append("The start codon is not certain; confirm it before designing.")
    if len(starts) > 1 and starts[0].confidence == starts[1].confidence:
        warnings.append("More than one start codon is plausible; pick the one the host uses.")
    return VectorAnalysis(
        vector=vector,
        flipped=flipped,
        orientation_notes=notes,
        starts=starts,
        region=region,
        warnings=warnings,
    )


def confirm(analysis: VectorAnalysis, *, start: int | None = None) -> Vector:
    """Fix the start codon on the (oriented) vector and return it.

    With no argument the best candidate is used, but only if it is certain.
    """
    v = analysis.vector
    if start is None:
        best = analysis.best_start
        if not best or best.confidence != "high":
            raise ValueError("The start codon is not certain; pass start= explicitly.")
        start = best.position
    if not 0 <= start <= len(v.seq) - 3 or v.seq[start : start + 3] != "ATG":
        raise ValueError(f"Position {start + 1} is not an ATG.")
    v.expression_start = start
    return v
